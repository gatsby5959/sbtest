package myClass;

public class arrayEx0 {
	public static void main(String[] args) {
	
		int[] score = {100, 90, 80, 70, 60};
		
		for(int i = 0; i < 5; i++) {
			System.out.println(score[i]);
		}
	}
}
