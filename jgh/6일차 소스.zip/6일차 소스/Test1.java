package myClass;
import java.util.*;
import java.util.ArrayList;

public class Test1 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
	}
}
